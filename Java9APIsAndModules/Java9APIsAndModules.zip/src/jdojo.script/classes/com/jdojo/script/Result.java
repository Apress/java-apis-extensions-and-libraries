// Result.java
package com.jdojo.script;

public class Result {
    private int val = -1;

    public void setValue(int x) {
        val = x;
    }

    public int getValue() {
        return val;
    }
}
