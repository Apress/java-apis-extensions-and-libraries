// Calculator.java
package com.jdojo.script;

public interface Calculator {
    int add (int n1, int n2);
    int subtract (int n1, int n2);    
}
