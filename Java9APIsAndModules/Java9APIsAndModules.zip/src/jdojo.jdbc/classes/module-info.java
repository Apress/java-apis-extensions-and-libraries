// module-info.java
module jdojo.jdbc {
    requires java.sql.rowset;
    
    exports com.jdojo.jdbc;
}
