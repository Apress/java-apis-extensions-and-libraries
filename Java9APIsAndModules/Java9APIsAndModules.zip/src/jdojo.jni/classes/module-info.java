// module-info.java
module jdojo.jni {
    exports com.jdojo.jni;
}
