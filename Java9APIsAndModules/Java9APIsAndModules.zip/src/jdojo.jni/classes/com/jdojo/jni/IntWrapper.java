// IntWrapper.java
package com.jdojo.jni;

public class IntWrapper {
    private int value = -1;

    public IntWrapper() {
    }    

    public IntWrapper(int value) {
        this.value = value;
    }
        
    public int getValue() {
        return value;
    }
}
