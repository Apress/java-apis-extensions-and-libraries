// EmbeddedJVMJNI.java
package com.jdojo.jni;

public class EmbeddedJVMJNI {
    public static void printMsg(String msg) {
        System.out.println(msg);
    }
}
