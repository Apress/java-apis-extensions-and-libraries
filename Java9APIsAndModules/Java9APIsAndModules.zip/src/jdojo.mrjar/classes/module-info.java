// module-info.java
module jdojo.mrjar {
    exports com.jdojo.mrjar;
}
