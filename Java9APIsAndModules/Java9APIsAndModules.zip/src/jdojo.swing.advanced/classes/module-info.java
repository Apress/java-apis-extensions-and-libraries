// module-info.java
module jdojo.swing.advanced {
    requires java.desktop;

    exports com.jdojo.swing.advanced;
}
