// module-info.java
module jdojo.rmi.server {
    requires java.rmi;
    requires jdojo.rmi.common;
    
    exports com.jdojo.rmi.server;
}
