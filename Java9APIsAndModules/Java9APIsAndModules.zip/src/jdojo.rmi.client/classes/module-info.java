// module-info.java
module jdojo.rmi.client {
    requires java.rmi;    
    requires jdojo.rmi.common;
    
    exports com.jdojo.rmi.client;
}
