// Test.java
package com.jdojo.swing.component;

public class Test {
    public static void main(String[] args) {
        Object[] a = {100};
        System.out.println(a[0].getClass());
    }
}
