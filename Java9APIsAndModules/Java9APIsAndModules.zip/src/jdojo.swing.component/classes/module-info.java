// module-info.java
module jdojo.swing.component {
    requires java.desktop;
    
    exports com.jdojo.swing.component;
}
