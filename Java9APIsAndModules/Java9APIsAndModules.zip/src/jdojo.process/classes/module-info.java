// module-info.java
module jdojo.process {
    exports com.jdojo.process;            
}
