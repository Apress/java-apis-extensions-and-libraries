// module-info.java
module jdojo.rmi.common {
    requires java.rmi;
    
    exports com.jdojo.rmi.common;
}
