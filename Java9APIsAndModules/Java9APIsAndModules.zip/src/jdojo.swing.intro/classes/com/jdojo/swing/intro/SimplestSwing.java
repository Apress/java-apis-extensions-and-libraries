// SimplestSwing.java
package com.jdojo.swing.intro;

import javax.swing.JFrame;

public class SimplestSwing {
    public static void main(String[] args) {
        // Create a frame
        JFrame frame = new JFrame("Simplest Swing");

        // Display the frame
        frame.setVisible(true);
    }
}
