// module-info.java
module jdojo.swing.intro {
    requires java.desktop;
}
