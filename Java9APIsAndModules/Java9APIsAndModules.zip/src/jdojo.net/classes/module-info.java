// module-info.java
module jdojo.net {
    exports com.jdojo.net;
}
