// module-info.java
module jdojo.script {
    requires java.scripting;

    exports com.jdojo.script;
}
