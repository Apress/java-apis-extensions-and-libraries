// Test.java
package com.jdojo.script;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Test {
    public static void main(String[] args) {
        // Create an script engine manager
        ScriptEngineManager manager = new ScriptEngineManager();

        // Get the reference of the Nashorn engine
        ScriptEngine engine = manager.getEngineByName("JavaScript");

        System.out.println(engine.getFactory().getNames());
        
        // Store a Nashorn script in a string
        String script = "print('Hello Scripting!')";
        
        try {
            engine.eval(script);
        } catch (ScriptException ex) {
            ex.printStackTrace();
        }
    }
}
